# ripunzip

[![GitHub](https://img.shields.io/crates/l/ripunzip)](https://github.com/google/ripunzip)
[![crates.io](https://img.shields.io/crates/d/ripunzip)](https://crates.io/crates/ripunzip)
[![docs.rs](https://docs.rs/ripunzip/badge.svg)](https://docs.rs/ripunzip)

A tool to unzip files in parallel.

#### License and usage notes

This is not an officially supported Google product.

<sup>
License

This software is distributed under the terms of both the MIT license and the
Apache License (Version 2.0).

See LICENSE for details.
</sup>

